public class Ejercicio1 {

    public boolean esPositivo(int numero) {
        if (numero >= 0) {
            return true;
        } else {
            return false;
        }
    }
}
